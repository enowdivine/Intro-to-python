#Name: Isong Mbah
#Date: June 16 2022
#Project: Time calculations in hours. A program that takes the input value of distance 
#         in miles and speed value in mph and calculate the arrival time in hours

import turtle

distance = turtle.numinput("Input", "Enter distance in miles")
speed = turtle.numinput("Input", "Enter speed mph")

time = distance / speed

print(f'{time:.4f}')

