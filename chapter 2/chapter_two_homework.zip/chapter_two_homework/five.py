Python 3.8.10 (default, Mar 15 2022, 12:22:08) 
[GCC 9.4.0] on linux
Type "help", "copyright", "credits" or "license()" for more information.
>>> #5
>>> userWeight = float(input("Enter your weight: "))
Enter your weight: 55.5
>>> userWeight
55.5
>>> userWeight = float(input("Enter your weight: "))
Enter your weight: 45
>>> userWeight
45.0
>>> 