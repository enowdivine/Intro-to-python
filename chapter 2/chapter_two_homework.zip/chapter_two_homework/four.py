Python 3.8.10 (default, Mar 15 2022, 12:22:08) 
[GCC 9.4.0] on linux
Type "help", "copyright", "credits" or "license()" for more information.
>>> #4
>>> userAge = int(input("Enter your age: "))
Enter your age: 20
>>> userAge
20
>>> 