#add preamble here

#declareGlobals here

def main():
    #initialize globals
    initializeGlobals()
    
    #declare local quantity variables
    qtPizza = 0
    qtFries = 0
    qtDrinks = 0

    #loop main tasks
    flag = True
    while flag:
        selection = displayMenu()

        if selection == "p":
            qtPizza = getQuantity("Pizza slices")
        elif selection == "f":
            qtFries = getQuantity("Fries")
        elif selection == "d":
            qtDrinks = getQuantity("Drinks")
        elif selection == "e":
            flag = False
        else:
            printBill(qtPizza, qtFries, qtDrinks)
            qtPizza = 0
            qtFries = 0
            qtDrinks = 0
            
if __name__ == "__main__":
    main()


    
        
        
