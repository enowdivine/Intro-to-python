def times_ten(arg):
    print(f"{arg * arg * 10}")

times_ten(2)